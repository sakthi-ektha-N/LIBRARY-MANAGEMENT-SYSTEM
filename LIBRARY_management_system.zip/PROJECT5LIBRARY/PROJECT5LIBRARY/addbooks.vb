﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class addbooks
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Public NameFrm, NameTo As String
    Private Sub addbooks_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the '_project5_libraryDataSet.tbl_book' table. You can move, or remove it, as needed.
        Me.Tbl_bookTableAdapter.Fill(Me._project5_libraryDataSet.tbl_book)

        con.ConnectionString = "Data Source=laptop-054ffkja\sqlexpress;Initial Catalog=project5-library;Integrated Security=True;Pooling=False"
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        'MessageBox.Show("connection established")
    End Sub

    Private Sub Btnexit_Click(sender As System.Object, e As System.EventArgs) Handles Btnexit.Click
        Me.Close()
        mainform.Show()
    End Sub
    Sub Sentence()
        Dim a, b As Integer
        a = NameFrm.Length
        NameTo = ""
        For b = 0 To a - 1
            If b = 0 Then
                If Char.IsLower(NameFrm(0)) Then
                    NameTo = Char.ToUpper(NameFrm(0))
                Else
                    NameTo = NameFrm(0)
                End If
            Else
                If NameFrm(b - 1) = " " Then
                    NameTo = NameTo + Char.ToUpper(NameFrm(b))
                Else
                    NameTo = NameTo + NameFrm(b)
                End If
            End If
        Next
    End Sub
    Sub disable()
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        TextBox5.Enabled = False
        ComboBox3.Enabled = False
    End Sub
    Public Sub enablethem()
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        TextBox4.Enabled = True
        TextBox5.Enabled = True
        ComboBox3.Enabled = True
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        ComboBox3.Text = ""
    End Sub
    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select*from tbl_book "
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Btnadd.Click
        ComboBox3.Text = "Available"
        Call enablethem()
    End Sub

    Private Sub Btnsave_Click(sender As System.Object, e As System.EventArgs) Handles Btnsave.Click
        If TextBox1.Text = "" Then
            MsgBox("Please enter the Book ID!", 0, "")
        Else
            Try
                If con.State = ConnectionState.Closed Then con.Open()
                Dim cmd As New SqlCommand("insert into tbl_book values(" + TextBox1.Text + ",'" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox5.Text + "','" + TextBox4.Text + "','" + ComboBox3.Text + "')", con)
                cmd.ExecuteNonQuery()

                disp_data()
                MessageBox.Show("Book added successfully")
            Catch ex As Exception
                MsgBox(ex.Message, 0, "")
            End Try
        End If
    End Sub

    Private Sub Btndel_Click(sender As System.Object, e As System.EventArgs) Handles Btndel.Click
        Try
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
            con.Open()
            If MessageBox.Show("Do you really want to delete?", "ARE YOU SURE", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Dim cmd As SqlCommand = New SqlCommand("DELETE FROM [dbo].[tbl_book] WHERE bookID ='" + TextBox1.Text + "'", con)
                cmd.ExecuteNonQuery()

                disp_data()
                MessageBox.Show("BOOK Deleted")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DataGridView1_CellClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        'the try catch statement is used to handle any exception if formed.
        'using the index we select a particular row in the grid view data to undergo insert,update,del,search operation.
        Try
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
            con.Open()
            Dim i As Integer
            i = e.RowIndex
            Dim selectedrow As DataGridViewRow
            selectedrow = DataGridView1.Rows(i)
            TextBox1.Text = selectedrow.Cells(0).Value.ToString()
            TextBox2.Text = selectedrow.Cells(1).Value.ToString()
            TextBox3.Text = selectedrow.Cells(2).Value.ToString()
            TextBox5.Text = selectedrow.Cells(3).Value.ToString()
            ComboBox3.Text = selectedrow.Cells(4).Value.ToString()
            TextBox4.Text = selectedrow.Cells(5).Value.ToString()


        Catch ex As Exception

        End Try
    End Sub

    Private Sub TextBox2_LostFocus(sender As Object, e As System.EventArgs) Handles TextBox2.LostFocus
        NameFrm = TextBox2.Text
        Call Sentence()
        TextBox2.Text = NameTo
    End Sub

    Private Sub TextBox3_LostFocus(sender As Object, e As System.EventArgs) Handles TextBox3.LostFocus
        NameFrm = TextBox3.Text
        Call Sentence()
        TextBox3.Text = NameTo
    End Sub

    Private Sub TextBox4_LostFocus(sender As Object, e As System.EventArgs) Handles TextBox4.LostFocus
        NameFrm = TextBox4.Text
        Call Sentence()
        TextBox4.Text = NameTo
    End Sub

    Private Sub TextBox5_LostFocus(sender As Object, e As System.EventArgs) Handles TextBox5.LostFocus
        NameFrm = TextBox5.Text
        Call Sentence()
        TextBox5.Text = NameTo
    End Sub
End Class