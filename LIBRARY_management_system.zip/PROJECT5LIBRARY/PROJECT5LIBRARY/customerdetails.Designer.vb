﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class customerdetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(customerdetails))
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Btnexit = New System.Windows.Forms.Button()
        Me.Btndel = New System.Windows.Forms.Button()
        Me.Btnsave = New System.Windows.Forms.Button()
        Me.Btnadd = New System.Windows.Forms.Button()
        Me.TblcustomerBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me._project5_libraryDataSet1 = New PROJECT5LIBRARY._project5_libraryDataSet1()
        Me.Tbl_customerTableAdapter = New PROJECT5LIBRARY._project5_libraryDataSet1TableAdapters.tbl_customerTableAdapter()
        Me.Label5 = New System.Windows.Forms.Label()
        Me._project5_libraryDataSet2 = New PROJECT5LIBRARY._project5_libraryDataSet2()
        Me.TblcustomerBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Tbl_customerTableAdapter1 = New PROJECT5LIBRARY._project5_libraryDataSet2TableAdapters.tbl_customerTableAdapter()
        Me.Label6 = New System.Windows.Forms.Label()
        Me._project5_libraryDataSet3 = New PROJECT5LIBRARY._project5_libraryDataSet3()
        Me.TblcustomerBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Tbl_customerTableAdapter2 = New PROJECT5LIBRARY._project5_libraryDataSet3TableAdapters.tbl_customerTableAdapter()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.CustomerIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomernameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CustomeraddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContactnoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MembershipDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblcustomerBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me._project5_libraryDataSet4 = New PROJECT5LIBRARY._project5_libraryDataSet4()
        Me.Tbl_customerTableAdapter3 = New PROJECT5LIBRARY._project5_libraryDataSet4TableAdapters.tbl_customerTableAdapter()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GroupBox3.SuspendLayout()
        CType(Me.TblcustomerBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._project5_libraryDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._project5_libraryDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblcustomerBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._project5_libraryDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblcustomerBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblcustomerBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._project5_libraryDataSet4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.ForeColor = System.Drawing.Color.MediumAquamarine
        Me.TextBox4.Location = New System.Drawing.Point(212, 196)
        Me.TextBox4.MaxLength = 10
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextBox4.Size = New System.Drawing.Size(159, 22)
        Me.TextBox4.TabIndex = 18
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(212, 113)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox3.Size = New System.Drawing.Size(224, 63)
        Me.TextBox3.TabIndex = 17
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.TextBox2.Location = New System.Drawing.Point(212, 78)
        Me.TextBox2.MaxLength = 50
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextBox2.Size = New System.Drawing.Size(224, 22)
        Me.TextBox2.TabIndex = 16
        '
        'TextBox1
        '
        Me.TextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(212, 44)
        Me.TextBox1.MaxLength = 30
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextBox1.Size = New System.Drawing.Size(58, 22)
        Me.TextBox1.TabIndex = 15
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(23, 196)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(181, 16)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "CUSTOMER CONTACT #"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(34, 132)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(170, 16)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "CUSTOMER ADDRESS"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(54, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(140, 16)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "CUSTOMER NAME"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(82, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 16)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "CUSTOMER ID"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.LightSalmon
        Me.GroupBox3.Controls.Add(Me.Btnexit)
        Me.GroupBox3.Controls.Add(Me.Btndel)
        Me.GroupBox3.Controls.Add(Me.Btnsave)
        Me.GroupBox3.Controls.Add(Me.Btnadd)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(327, 410)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(481, 76)
        Me.GroupBox3.TabIndex = 19
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "CONTROL"
        '
        'Btnexit
        '
        Me.Btnexit.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnexit.Location = New System.Drawing.Point(361, 19)
        Me.Btnexit.Name = "Btnexit"
        Me.Btnexit.Size = New System.Drawing.Size(99, 38)
        Me.Btnexit.TabIndex = 4
        Me.Btnexit.Text = "EXIT"
        Me.Btnexit.UseVisualStyleBackColor = True
        '
        'Btndel
        '
        Me.Btndel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btndel.Location = New System.Drawing.Point(239, 19)
        Me.Btndel.Name = "Btndel"
        Me.Btndel.Size = New System.Drawing.Size(105, 38)
        Me.Btndel.TabIndex = 3
        Me.Btndel.Text = "UPDATE"
        Me.Btndel.UseVisualStyleBackColor = True
        '
        'Btnsave
        '
        Me.Btnsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnsave.Location = New System.Drawing.Point(132, 19)
        Me.Btnsave.Name = "Btnsave"
        Me.Btnsave.Size = New System.Drawing.Size(96, 38)
        Me.Btnsave.TabIndex = 1
        Me.Btnsave.Text = "SAVE"
        Me.Btnsave.UseVisualStyleBackColor = True
        '
        'Btnadd
        '
        Me.Btnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnadd.Location = New System.Drawing.Point(15, 19)
        Me.Btnadd.Name = "Btnadd"
        Me.Btnadd.Size = New System.Drawing.Size(104, 38)
        Me.Btnadd.TabIndex = 0
        Me.Btnadd.Text = "ADD NEW"
        Me.Btnadd.UseVisualStyleBackColor = True
        '
        'TblcustomerBindingSource
        '
        Me.TblcustomerBindingSource.DataMember = "tbl_customer"
        Me.TblcustomerBindingSource.DataSource = Me._project5_libraryDataSet1
        '
        '_project5_libraryDataSet1
        '
        Me._project5_libraryDataSet1.DataSetName = "_project5_libraryDataSet1"
        Me._project5_libraryDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Tbl_customerTableAdapter
        '
        Me.Tbl_customerTableAdapter.ClearBeforeFill = True
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.LightSalmon
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label5.Font = New System.Drawing.Font("Maiandra GD", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(0, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(1123, 56)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "CUSTOMER DETAILS"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '_project5_libraryDataSet2
        '
        Me._project5_libraryDataSet2.DataSetName = "_project5_libraryDataSet2"
        Me._project5_libraryDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblcustomerBindingSource1
        '
        Me.TblcustomerBindingSource1.DataMember = "tbl_customer"
        Me.TblcustomerBindingSource1.DataSource = Me._project5_libraryDataSet2
        '
        'Tbl_customerTableAdapter1
        '
        Me.Tbl_customerTableAdapter1.ClearBeforeFill = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.PaleTurquoise
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(96, 238)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(108, 16)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "MEMBERSHIP"
        '
        '_project5_libraryDataSet3
        '
        Me._project5_libraryDataSet3.DataSetName = "_project5_libraryDataSet3"
        Me._project5_libraryDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblcustomerBindingSource2
        '
        Me.TblcustomerBindingSource2.DataMember = "tbl_customer"
        Me.TblcustomerBindingSource2.DataSource = Me._project5_libraryDataSet3
        '
        'Tbl_customerTableAdapter2
        '
        Me.Tbl_customerTableAdapter2.ClearBeforeFill = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"PRESENT CUSTOMER", "NO LONGER A CUSTOMER"})
        Me.ComboBox1.Location = New System.Drawing.Point(212, 238)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(159, 21)
        Me.ComboBox1.TabIndex = 25
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.PeachPuff
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CustomerIDDataGridViewTextBoxColumn, Me.CustomernameDataGridViewTextBoxColumn, Me.CustomeraddressDataGridViewTextBoxColumn, Me.ContactnoDataGridViewTextBoxColumn, Me.MembershipDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TblcustomerBindingSource3
        Me.DataGridView1.Location = New System.Drawing.Point(558, 139)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(550, 214)
        Me.DataGridView1.TabIndex = 26
        '
        'CustomerIDDataGridViewTextBoxColumn
        '
        Me.CustomerIDDataGridViewTextBoxColumn.DataPropertyName = "customer_ID"
        Me.CustomerIDDataGridViewTextBoxColumn.HeaderText = "customer_ID"
        Me.CustomerIDDataGridViewTextBoxColumn.Name = "CustomerIDDataGridViewTextBoxColumn"
        '
        'CustomernameDataGridViewTextBoxColumn
        '
        Me.CustomernameDataGridViewTextBoxColumn.DataPropertyName = "customer_name"
        Me.CustomernameDataGridViewTextBoxColumn.HeaderText = "customer_name"
        Me.CustomernameDataGridViewTextBoxColumn.Name = "CustomernameDataGridViewTextBoxColumn"
        '
        'CustomeraddressDataGridViewTextBoxColumn
        '
        Me.CustomeraddressDataGridViewTextBoxColumn.DataPropertyName = "customer_address"
        Me.CustomeraddressDataGridViewTextBoxColumn.HeaderText = "customer_address"
        Me.CustomeraddressDataGridViewTextBoxColumn.Name = "CustomeraddressDataGridViewTextBoxColumn"
        '
        'ContactnoDataGridViewTextBoxColumn
        '
        Me.ContactnoDataGridViewTextBoxColumn.DataPropertyName = "contact_no"
        Me.ContactnoDataGridViewTextBoxColumn.HeaderText = "contact_no"
        Me.ContactnoDataGridViewTextBoxColumn.Name = "ContactnoDataGridViewTextBoxColumn"
        '
        'MembershipDataGridViewTextBoxColumn
        '
        Me.MembershipDataGridViewTextBoxColumn.DataPropertyName = "membership"
        Me.MembershipDataGridViewTextBoxColumn.HeaderText = "membership"
        Me.MembershipDataGridViewTextBoxColumn.Name = "MembershipDataGridViewTextBoxColumn"
        '
        'TblcustomerBindingSource3
        '
        Me.TblcustomerBindingSource3.DataMember = "tbl_customer"
        Me.TblcustomerBindingSource3.DataSource = Me._project5_libraryDataSet4
        '
        '_project5_libraryDataSet4
        '
        Me._project5_libraryDataSet4.DataSetName = "_project5_libraryDataSet4"
        Me._project5_libraryDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Tbl_customerTableAdapter3
        '
        Me.Tbl_customerTableAdapter3.ClearBeforeFill = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PeachPuff
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.ComboBox1)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.TextBox1)
        Me.Panel1.Controls.Add(Me.TextBox2)
        Me.Panel1.Controls.Add(Me.TextBox4)
        Me.Panel1.Controls.Add(Me.TextBox3)
        Me.Panel1.Location = New System.Drawing.Point(92, 114)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(447, 274)
        Me.Panel1.TabIndex = 27
        '
        'customerdetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MistyRose
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1123, 498)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.GroupBox3)
        Me.Name = "customerdetails"
        Me.Text = "customer details"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.TblcustomerBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._project5_libraryDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._project5_libraryDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblcustomerBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._project5_libraryDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblcustomerBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblcustomerBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._project5_libraryDataSet4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Btnexit As System.Windows.Forms.Button
    Friend WithEvents Btndel As System.Windows.Forms.Button
    Friend WithEvents Btnsave As System.Windows.Forms.Button
    Friend WithEvents Btnadd As System.Windows.Forms.Button
    Friend WithEvents _project5_libraryDataSet1 As PROJECT5LIBRARY._project5_libraryDataSet1
    Friend WithEvents TblcustomerBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Tbl_customerTableAdapter As PROJECT5LIBRARY._project5_libraryDataSet1TableAdapters.tbl_customerTableAdapter
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents _project5_libraryDataSet2 As PROJECT5LIBRARY._project5_libraryDataSet2
    Friend WithEvents TblcustomerBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents Tbl_customerTableAdapter1 As PROJECT5LIBRARY._project5_libraryDataSet2TableAdapters.tbl_customerTableAdapter
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents _project5_libraryDataSet3 As PROJECT5LIBRARY._project5_libraryDataSet3
    Friend WithEvents TblcustomerBindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents Tbl_customerTableAdapter2 As PROJECT5LIBRARY._project5_libraryDataSet3TableAdapters.tbl_customerTableAdapter
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents CustomerIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustomernameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CustomeraddressDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ContactnoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MembershipDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents _project5_libraryDataSet4 As PROJECT5LIBRARY._project5_libraryDataSet4
    Friend WithEvents TblcustomerBindingSource3 As System.Windows.Forms.BindingSource
    Friend WithEvents Tbl_customerTableAdapter3 As PROJECT5LIBRARY._project5_libraryDataSet4TableAdapters.tbl_customerTableAdapter
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
