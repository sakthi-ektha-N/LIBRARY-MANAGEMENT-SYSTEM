﻿Public Class customersreport

    Private Sub customersreport_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
       
        'TODO: This line of code loads data into the 'DataSet2.tbl_customer' table. You can move, or remove it, as needed.
        Me.tbl_customerTableAdapter.Fill(Me.DataSet2.tbl_customer)

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        mainform.Show()
        Me.Hide()
    End Sub
End Class