﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mainform))
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ToolTip2 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Button7 = New System.Windows.Forms.Button()
        Me.ToolTip3 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ToolTip4 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Button6 = New System.Windows.Forms.Button()
        Me.ToolTip5 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolTip6 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolTip7 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Btnexit = New System.Windows.Forms.Button()
        Me.ToolTip8 = New System.Windows.Forms.ToolTip(Me.components)
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), System.Drawing.Image)
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button4.Location = New System.Drawing.Point(2, 243)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(174, 172)
        Me.Button4.TabIndex = 10
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip6.SetToolTip(Me.Button4, "VIEW CUSTOMERS OF YOUR LIBRARY")
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), System.Drawing.Image)
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button5.Location = New System.Drawing.Point(0, 52)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(177, 167)
        Me.Button5.TabIndex = 11
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip5.SetToolTip(Me.Button5, "ADD NEW CUSTOMER TO YOUR LIBRARY")
        Me.Button5.UseVisualStyleBackColor = False
        '
        'ToolTip1
        '
        Me.ToolTip1.ShowAlways = True
        Me.ToolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip1.ToolTipTitle = "FUNCTION"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Location = New System.Drawing.Point(0, 22)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(169, 166)
        Me.Button1.TabIndex = 7
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip1.SetToolTip(Me.Button1, "ADD BOOKS TO YOUR LIBRARY")
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ToolTip2
        '
        Me.ToolTip2.ShowAlways = True
        Me.ToolTip2.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip2.ToolTipTitle = "FUNCTION"
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button7.BackgroundImage = CType(resources.GetObject("Button7.BackgroundImage"), System.Drawing.Image)
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button7.Location = New System.Drawing.Point(-3, 194)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(174, 161)
        Me.Button7.TabIndex = 13
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip2.SetToolTip(Me.Button7, "ISSUE BOOKS TO CUSTOMER")
        Me.Button7.UseVisualStyleBackColor = False
        '
        'ToolTip3
        '
        Me.ToolTip3.ShowAlways = True
        Me.ToolTip3.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip3.ToolTipTitle = "FUNCTION"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Location = New System.Drawing.Point(-3, 361)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(169, 158)
        Me.Button2.TabIndex = 8
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip3.SetToolTip(Me.Button2, "RETURN BOOKS TO THE LIBRARY")
        Me.Button2.UseVisualStyleBackColor = False
        '
        'ToolTip4
        '
        Me.ToolTip4.ShowAlways = True
        Me.ToolTip4.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip4.ToolTipTitle = "FUNCTION"
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), System.Drawing.Image)
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button6.Location = New System.Drawing.Point(-3, 525)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(169, 166)
        Me.Button6.TabIndex = 12
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip4.SetToolTip(Me.Button6, "LIBRARY'S BOOK REPORT")
        Me.Button6.UseVisualStyleBackColor = False
        '
        'ToolTip5
        '
        Me.ToolTip5.ShowAlways = True
        Me.ToolTip5.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip5.ToolTipTitle = "FUNCTION"
        '
        'ToolTip6
        '
        Me.ToolTip6.ShowAlways = True
        Me.ToolTip6.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip6.ToolTipTitle = "FUNCTION"
        '
        'ToolTip7
        '
        Me.ToolTip7.ShowAlways = True
        Me.ToolTip7.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip7.ToolTipTitle = "FUNCTION"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(169, 708)
        Me.Panel1.TabIndex = 15
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Btnexit)
        Me.Panel2.Controls.Add(Me.Button5)
        Me.Panel2.Controls.Add(Me.Button4)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(1052, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(176, 708)
        Me.Panel2.TabIndex = 16
        '
        'Btnexit
        '
        Me.Btnexit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Btnexit.BackgroundImage = CType(resources.GetObject("Btnexit.BackgroundImage"), System.Drawing.Image)
        Me.Btnexit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btnexit.Location = New System.Drawing.Point(2, 440)
        Me.Btnexit.Name = "Btnexit"
        Me.Btnexit.Size = New System.Drawing.Size(174, 186)
        Me.Btnexit.TabIndex = 12
        Me.Btnexit.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.ToolTip8.SetToolTip(Me.Btnexit, "EXIT THE APPLICATION")
        Me.Btnexit.UseVisualStyleBackColor = False
        '
        'ToolTip8
        '
        Me.ToolTip8.ShowAlways = True
        Me.ToolTip8.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip8.ToolTipTitle = "FUNCTION"
        '
        'PictureBox3
        '
        Me.PictureBox3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(437, 0)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(424, 722)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 20
        Me.PictureBox3.TabStop = False
        '
        'mainform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(1228, 708)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.IsMdiContainer = True
        Me.Name = "mainform"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ToolTip2 As System.Windows.Forms.ToolTip
    Friend WithEvents ToolTip3 As System.Windows.Forms.ToolTip
    Friend WithEvents ToolTip4 As System.Windows.Forms.ToolTip
    Friend WithEvents ToolTip5 As System.Windows.Forms.ToolTip
    Friend WithEvents ToolTip6 As System.Windows.Forms.ToolTip
    Friend WithEvents ToolTip7 As System.Windows.Forms.ToolTip
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Btnexit As System.Windows.Forms.Button
    Friend WithEvents ToolTip8 As System.Windows.Forms.ToolTip
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox

End Class
