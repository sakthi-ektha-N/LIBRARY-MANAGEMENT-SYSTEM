﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class issuebook
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Private Sub issuebook_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the '_project5_libraryDataSet9.tbl_issue' table. You can move, or remove it, as needed.
        Me.Tbl_issueTableAdapter2.Fill(Me._project5_libraryDataSet9.tbl_issue)
       
        con.ConnectionString = "Data Source=laptop-054ffkja\sqlexpress;Initial Catalog=project5-library;Integrated Security=True;Pooling=False"
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        'MessageBox.Show("connection established")
        TextBox6.Select()
    End Sub
    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select*from tbl_issue"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub
    Public Sub enablethem()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox7.Clear()
        TextBox8.Clear()
        TextBox6.Select()
        ComboBox4.Text = ""
        DateTimePicker1.Refresh()
        DateTimePicker2.Refresh()
    End Sub
    Private Sub TextBox6_LostFocus(sender As Object, e As System.EventArgs) Handles TextBox6.LostFocus
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select bookname,publisher,author,edition,status from tbl_book where bookID='" + TextBox6.Text + "'"
        cmd.ExecuteNonQuery()
        
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        If dt.Rows.Count() > 0 Then
            TextBox2.Text = dt.Rows(0)(0).ToString()
            TextBox3.Text = dt.Rows(0)(1).ToString()
            TextBox4.Text = dt.Rows(0)(2).ToString()
            TextBox5.Text = dt.Rows(0)(3).ToString()
            ComboBox4.Text = dt.Rows(0)(4).ToString()
            If ComboBox4.Text = "Rented" Then
                MsgBox("SORRY!! THIS BOOK IS ALREADY RENTED", MessageBoxIcon.Information)
                If MessageBox.Show("Do you want another book?", "ARE YOU SURE", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                    TextBox6.Select()
                End If
            End If
        Else
            MessageBox.Show("NO SUCH BOOK EXIST")

        End If
    End Sub

    Private Sub Btnexit_Click(sender As System.Object, e As System.EventArgs) Handles Btnexit.Click
        Me.Hide()
        mainform.Show()

    End Sub
    Private Sub TextBox7_LostFocus(sender As Object, e As System.EventArgs) Handles TextBox7.LostFocus
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select customer_name,membership from tbl_customer where customer_ID='" + TextBox7.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        If dt.Rows.Count() > 0 Then
            TextBox1.Text = dt.Rows(0)(0).ToString()
            TextBox8.Text = dt.Rows(0)(1).ToString()
            If TextBox8.Text = "NO LONGER A CUSTOMER" Then
                MsgBox("KINDLY BECOME A MEMBER TO BORROW BOOKS FROM HERE", MessageBoxIcon.Information)
                If MessageBox.Show("Do you really want to become a member?", "ARE YOU SURE", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                    customerdetails.Show()
                Else
                    Call enablethem()
                End If
            End If
        Else
            MessageBox.Show("NO SUCH CUSTOMER EXIST")
        End If
    End Sub
   
    Private Sub Btnsave_Click(sender As System.Object, e As System.EventArgs) Handles Btnsave.Click
        If TextBox7.Text = "" Then
            MsgBox("Please enter the customer ID!", 0, "")
        Else
            Try
               
                If con.State = ConnectionState.Closed Then con.Open()
                Dim datetime As String = "31-12-9998"
                Dim D As DateTime = Convert.ToDateTime(datetime)
                Dim format As String = "yyyy-MM-dd"
                Dim str1 As String = D.ToString(format)
                Dim cmd As New SqlCommand("insert into tbl_issue values(" + TextBox6.Text + ",'" + TextBox2.Text + "','" + TextBox7.Text + "','" + DateTimePicker1.Value.ToString(format) + "','" + DateTimePicker2.Value.ToString(format) + "','" + ComboBox1.Text + "')", con)
                cmd.ExecuteNonQuery()
                disp_data()
                Dim cmd1 As New SqlCommand("update tbl_book set status='Rented' WHERE BookID='" & TextBox6.Text & "'", con)
                cmd1.ExecuteNonQuery()

                MsgBox("CONGRATULATIONS!! ENJOY READING", MsgBoxStyle.Information)

            Catch ex As Exception
                MsgBox(ex.Message, 0, "")
            End Try
        End If
        
    End Sub
    Private Sub DataGridView1_CellClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        'the try catch statement is used to handle any exception if formed.
        'using the index we select a particular row in the grid view data to undergo insert,update,del,search operation.
        Try
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
            con.Open()
            Dim i As Integer
            i = e.RowIndex
            Dim selectedrow As DataGridViewRow
            selectedrow = DataGridView1.Rows(i)
            TextBox6.Text = selectedrow.Cells(0).Value.ToString()
            TextBox2.Text = selectedrow.Cells(1).Value.ToString()
            TextBox7.Text = selectedrow.Cells(2).Value.ToString()
            DateTimePicker1.Value = selectedrow.Cells(3).Value.ToString()
            DateTimePicker2.Text = selectedrow.Cells(4).Value.ToString()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btnadd_Click(sender As System.Object, e As System.EventArgs) Handles Btnadd.Click
        Call enablethem()
    End Sub

   
End Class