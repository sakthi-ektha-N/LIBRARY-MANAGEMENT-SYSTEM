﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class returnbook
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    'FORM LOAD 
    Private Sub returnbook_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the '_project5_libraryDataSet10.tbl_issue' table. You can move, or remove it, as needed.
        Me.Tbl_issueTableAdapter1.Fill(Me._project5_libraryDataSet10.tbl_issue)
       
       
        con.ConnectionString = "Data Source=laptop-054ffkja\sqlexpress;Initial Catalog=project5-library;Integrated Security=True;Pooling=False"
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        'MessageBox.Show("connection established")
        TextBox4.Select()
    End Sub
    'EXIT FORM BUTTON
    Private Sub Button9_Click(sender As System.Object, e As System.EventArgs) Handles Button9.Click
        Me.Hide()
        mainform.Show()

    End Sub
    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select*from tbl_issue"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub
    Public Sub enablethem()
        disp_data()
        Label6.Visible = False
        Label7.Visible = False
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox7.Clear()
        TextBox4.Select()
        TextBox6.Clear()
        DateTimePicker2.Refresh()
    End Sub
    ' ADD NEW RETURN BUTTON
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Call enablethem()
    End Sub

   
    'RETURN BOOK BUTTON
    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        If TextBox4.Text = "" Then
            MsgBox("Please enter the Book ID!", 0, "")
        ElseIf TextBox5.Text = "" Then
            MsgBox("Please enter the customer ID!", 0, "")
        Else
            Try
                

                Dim due As DateTime = Convert.ToDateTime(TextBox7.Text)
                Dim returning As DateTime = Convert.ToDateTime(DateTimePicker2.Text)
                Dim countdays As TimeSpan = returning.Subtract(due)
                Dim totaldays = Convert.ToInt32(countdays.Days)
                If Convert.ToInt32(countdays.Days) Then
                    TextBox6.Text = totaldays
                    If totaldays > 0 Then
                        Label6.Visible = True
                    Else
                        Label7.Visible = True
                    End If
                End If

                If con.State = ConnectionState.Closed Then con.Open()

                Dim datetime As String = "31-12-9998"
                Dim D As DateTime = Convert.ToDateTime(TextBox7.Text)
                Dim format As String = "yyyy-MM-dd"
                Dim str1 As String = D.ToString(format)
                Dim cmd As New SqlCommand("insert into tbl_return values(" + TextBox4.Text + ",'" + TextBox5.Text + "','" & str1 & "','" + DateTimePicker2.Value.ToString(format) + "')", con)
                cmd.ExecuteNonQuery()

                Dim cmd1 As New SqlCommand("update tbl_book set status='Available' WHERE BookID='" & TextBox4.Text & "'", con)
                cmd1.ExecuteNonQuery()
                Dim cmd2 As New SqlCommand("update tbl_issue set return_status='Returned' where bookID='" & TextBox4.Text & "'and issue_to='" + TextBox5.Text + "'", con)
                cmd2.ExecuteNonQuery()
                disp_data()
                MsgBox("THANK YOUU!! ENJOY READING", MsgBoxStyle.Information)

            Catch ex As Exception
                MsgBox(ex.Message, 0, "")
            End Try
        End If
    End Sub

    'Private Sub TextBox4_LostFocus(sender As Object, e As System.EventArgs) Handles TextBox4.LostFocus
    '    cmd = con.CreateCommand()
    '    cmd.CommandType = CommandType.Text
    '    cmd.CommandText = "select bookname,issue_to,issue_date,due_date from tbl_issue where bookID='" + TextBox4.Text + "'"
    '    cmd.ExecuteNonQuery()

    '    Dim dt As New DataTable()
    '    Dim da As New SqlDataAdapter(cmd)
    '    da.Fill(dt)
    '    If dt.Rows.Count() > 0 Then
    '        TextBox2.Text = dt.Rows(0)(0).ToString()
    '        TextBox5.Text = dt.Rows(0)(1).ToString()
    '        TextBox3.Text = dt.Rows(0)(2).ToString()
    '        TextBox7.Text = dt.Rows(0)(3).ToString()
    '    Else
    '        MessageBox.Show("NO SUCH BOOK EXIST")

    '    End If
    'End Sub

    'Private Sub TextBox5_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox5.TextChanged
    '    cmd = con.CreateCommand()  cmd = con.CreateCommand()
    '    cmd.CommandType = CommandType.Text
    '    cmd.CommandText = "select bookname,issue_to,issue_date,due_date from tbl_issue where bookID='" + TextBox4.Text + "'"
    '    cmd.ExecuteNonQuery()

    '    Dim dt As New DataTable()
    '    Dim da As New SqlDataAdapter(cmd)
    '    da.Fill(dt)
    '    If dt.Rows.Count() > 0 Then
    '        TextBox2.Text = dt.Rows(0)(0).ToString()
    '        TextBox5.Text = dt.Rows(0)(1).ToString()
    '        TextBox3.Text = dt.Rows(0)(2).ToString()
    '        TextBox7.Text = dt.Rows(0)(3).ToString()
    '    Else
    '        MessageBox.Show("NO SUCH BOOK EXIST")

    '    End If
    'End Sub

    'Private Sub TextBox5_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox5.TextChanged
    '    cmd = con.CreateCommand()
    '    cmd.CommandType = CommandType.Text
    '    cmd.CommandText = "select customer_name from tbl_customer where customer_ID='" + TextBox5.Text + "'"
    '    cmd.ExecuteNonQuery()

    '    Dim dt As New DataTable()
    '    Dim da As New SqlDataAdapter(cmd)
    '    da.Fill(dt)
    '    If dt.Rows.Count() > 0 Then
    '        TextBox1.Text = dt.Rows(0)(0).ToString()
    '        Else
    '        MessageBox.Show("NO SUCH CUSTOMER EXIST")

    '    End If
    'End Sub


    ' Private Sub DataGridView1_CellClick_1(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
    'the try catch statement is u
    '    cmd.CommandType = CommandType.Text
    '    cmd.CommandText = "select customer_name from tbl_customer where customer_ID='" + TextBox5.Text + "'"
    '    cmd.ExecuteNonQuery()

    '    Dim dt As New DataTable()
    '    Dim da As New SqlDataAdapter(cmd)
    '    da.Fill(dt)
    '    If dt.Rows.Count() > 0 Then
    '        TextBox1.Text = dt.Rows(0)(0).ToString()
    '        Else
    '        MessageBox.Show("NO SUCH CUSTOMER EXIST")

    '    End If
    'End Sub

    Private Sub DataGridView1_CellClick_1(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        'the try catch statement is used to handle any exception if formed.
        'using the index we select a particular row in the grid view data to undergo insert,update,del,search operation.
        Try
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
            con.Open()
            Dim i As Integer
            i = e.RowIndex
            Dim selectedrow As DataGridViewRow
            selectedrow = DataGridView1.Rows(i)
            TextBox4.Text = selectedrow.Cells(0).Value.ToString()
            TextBox5.Text = selectedrow.Cells(2).Value.ToString()
            TextBox7.Text = selectedrow.Cells(4).Value.ToString()
            DateTimePicker2.Text = selectedrow.Cells(5).Value.ToString()

        Catch ex As Exception

        End Try
    End Sub


    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from tbl_issue where bookID='" + TextBox4.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub TextBox5_LostFocus(sender As Object, e As System.EventArgs) Handles TextBox5.LostFocus
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from tbl_issue where issue_to='" + TextBox5.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub TextBox7_TextChanged(sender As System.Object, e As System.EventArgs) Handles TextBox7.TextChanged

    End Sub
End Class