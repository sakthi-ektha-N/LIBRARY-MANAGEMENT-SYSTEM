﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class mainform
    Dim con As New SqlConnection
    Private Sub mainform_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        con.ConnectionString = "Data Source=laptop-054ffkja\sqlexpress;Initial Catalog=project5-library;Integrated Security=True;Pooling=False"
        If con.State = ConnectionState.Open Then
            con.Close()

        End If
        con.Open()
        'MessageBox.Show("connection established")
        'making mdi parent form
        Dim add As New addbooks
        add.MdiParent = Me
        Dim issue As New issuebook
        issue.MdiParent = Me
        Dim returns As New returnbook
        returns.MdiParent = Me
        Dim cusdetails As New customerdetails
        cusdetails.MdiParent = Me
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        addbooks.Show()
        Me.Hide()
    End Sub

    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        issuebook.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        returnbook.Show()
        Me.Hide()
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        bookreport.Show()
        Me.Hide()
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        customerdetails.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        customersreport.Show()
        Me.Hide()
    End Sub

    Private Sub Btnexit_Click(sender As System.Object, e As System.EventArgs) Handles Btnexit.Click
        End
    End Sub
End Class